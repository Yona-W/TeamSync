So, I guess I have to write this because people are stupid sometimes.

I WILL NOT TAKE ANY KIND RESPONSABILITY IF MY PROGRAM DOES ANYTHING, SUCH AS TELLING EVERYONE YOUR PASSWORDS, BANK ACCOUNTS, AND STUFF LIKE THAT. IF IT HAPPENS, IT MEANS YOU DID SOMETHING YOU WEREN'T SUPPOSED TO DO. CLOSE TEAMSYNC BEFORE DOING ANYTHING YOU DON'T WANT OTHER PEOPLE TO SEE.

OK, that should be enough.

So, you just have to run TeamSync.exe and connect to the same room and server as the people you want to play with. Be careful, while the program is open it reads your keypresses.